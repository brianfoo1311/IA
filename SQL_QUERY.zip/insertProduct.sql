insert into tbl_Product (Product_Name, Product_Type, Product_Price)
values ('Intel Core i5-12600K', 'Processor', 1599.00);

insert into tbl_Product (Product_Name, Product_Type, Product_Price)
values ('Gigabyte Z690 Aorus Pro', 'Motherboard', 1698.00);

insert into tbl_Product (Product_Name, Product_Type, Product_Price)
values ('AMD Radeon 6900 XT', 'Graphic Card', 4196.80);

insert into tbl_Product (Product_Name, Product_Type, Product_Price)
values ('Corsair CX450', 'PSU', 252.00);

insert into tbl_Product (Product_Name, Product_Type, Product_Price)
values ('BenQ PD3200U 32 inch', 'Monitor', 3149.00);

insert into tbl_Product (Product_Name, Product_Type, Product_Price)
values ('Sonos Roam', 'Speaker', 1199.00);

insert into tbl_Product (Product_Name, Product_Type, Product_Price)
values ('Samsung MUF-AB 256GB FIT PLUS USB 3.1 Flash Stick Memory Drive', 'USB', 248.89);

insert into tbl_Product (Product_Name, Product_Type, Product_Price)
values ('SEAGATE BACKUP PLUS 4TB', 'Hard drive', 388.00);

insert into tbl_Product (Product_Name, Product_Type, Product_Price)
values ('Logitech MX Master 3', 'Mouse', 367.00);

insert into tbl_Product (Product_Name, Product_Type, Product_Price)
values ('Razer Huntsman V2 Analog', 'Keyboard', 1199.00);