insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (1, 1, 1, 1, '2021-01-25', 1599.00);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (1, 2, 1, 2, '2021-01-25', 4797.00);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (2, 3, 1, 14, '2021-01-27', 1599.00);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (2, 4, 2, 3, '2021-01-29', 6792.00);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (1, 1, 2, 16, '2021-01-29', 3396.00);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (2, 4, 2, 20, '2021-02-01', 1698.80);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (1, 1, 3, 10, '2021-02-01', 4196.80);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (3, 6, 3, 18, '2021-02-01', 4196.80);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (1, 2, 3, 25, '2021-02-01', 4196.80);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (1, 2, 4, 23, '2021-02-01', 252.00);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (3, 5, 5, 5, '2021-02-05', 6298.00);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (3, 6, 5, 22, '2021-02-08', 6298.80);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (3, 5, 5, 27, '2021-06-30', 6298.80);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (2, 3, 6, 4, '2021-02-08', 1199.00);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (2, 3, 6, 24, '2021-02-08', 2398.00);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (1, 1, 6, 26, '2021-06-18', 1199.00);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (1, 1, 7, 12, '2021-02-09', 497.78);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (1, 2, 7, 19, '2021-02-10', 248.89);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (2, 4, 7, 21, '2021-02-01', 497.89);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (1, 1, 8, 7, '2021-03-01', 388.00);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (1, 2, 8, 8, '2021-03-25', 1940.00);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (3, 6, 8, 15, '2021-04-01', 776.00);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (2, 4, 9, 11, '2021-04-22', 734.00);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (2, 3, 10, 6, '2021-05-14', 2398.00);

insert into tbl_Sales (Branch_ID, Staff_ID, Product_ID, Order_ID, Sales_Date, Total_Sales) values (1, 2, 10, 13, '2021-05-31', 1199.00);