select product_name as product, total_sales as total
from tbl_sales 
inner join tbl_order on tbl_Order.order_id = tbl_sales.order_id 
inner join tbl_product on tbl_product.product_id = tbl_order.product_id;

select branch_name as branch,total_sales as total 
from tbl_sales 
inner join tbl_Branch on tbl_Branch.branch_id = tbl_sales.branch_id;

select Branch_Name, MONTHName(Sales_Date) as Month, Total_Sales as Sales
From tbl_Sales
inner join tbl_Branch on tbl_Branch.Branch_ID = tbl_Sales.Branch_ID
inner join tbl_Order on tbl_Order.Order_ID = tbl_Sales.Order_ID;

select branch_name, staff_name,total_sales as sales 
from tbl_sales 
inner join tbl_staff on tbl_staff.staff_id = tbl_sales.staff_id 
inner join tbl_branch on tbl_branch.branch_id = tbl_staff.branch_id;

SELECT staff_name as staff,total_sales as sales 
from tbl_sales 
inner join tbl_staff on tbl_staff.staff_id = tbl_sales.staff_id;