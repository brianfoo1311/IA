insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (1, 1, 1);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (1, 1, 3);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (2, 5, 4);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (6, 3, 1);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (5, 2, 2);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (10, 7, 2);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (8, 15, 1);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (8, 14, 5);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (3, 10, 1);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (9, 6, 2);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (7, 7, 2);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (10, 5, 1);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (1, 15, 1);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (8, 12, 2);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (2, 6, 2);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (3, 11, 1);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (7, 10, 1);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (2, 11, 1);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (7, 12, 2);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (5, 15, 2);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (4, 10, 1);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (6, 8, 2);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (3, 12, 1);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (6, 14, 1);

insert into tbl_Order (Product_ID, Customer_ID, Quantity) values (5, 6, 2);