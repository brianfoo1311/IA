insert into tbl_Staff (Branch_ID, Team_ID, Staff_Name, 
Staff_Address, Staff_Phone, Staff_Position) 
values (1, 1, 'Alif', '1a, taman bukit jalil, 58000, Kuala Lumpur',
'012-1011089', 'Sales Staff');

insert into tbl_Staff (Branch_ID, Team_ID, Staff_Name, 
Staff_Address, Staff_Phone, Staff_Position) 
values (1, 1, 'Ara', '11a, taman bukit gasing, 58200, Selangor',
'012-2001892', 'Sales Staff');

insert into tbl_Staff (Branch_ID, Team_ID, Staff_Name, 
Staff_Address, Staff_Phone, Staff_Position) 
values (2, 2, 'John', '25c, taman bukit ara, 58000, Kuala Lumpur',
'013-2145925', 'Sales Staff');

insert into tbl_Staff (Branch_ID, Team_ID, Staff_Name, 
Staff_Address, Staff_Phone, Staff_Position) 
values (2, 2, 'Wicks', '22a, taman jaya, 58200, Selangor',
'016-8147745', 'Sales Staff');

insert into tbl_Staff (Branch_ID, Team_ID, Staff_Name, 
Staff_Address, Staff_Phone, Staff_Position) 
values (3, 3, 'Kacang', '225a, taman kacang, 58200, Selangor',
'016-8147745', 'Sales Staff');

insert into tbl_Staff (Branch_ID, Team_ID, Staff_Name, 
Staff_Address, Staff_Phone, Staff_Position) 
values (3, 3, 'Icey', '224b, taman iso, 58200, Selangor',
'016-8147745', 'Sales Staff');