insert into tbl_Branch (Branch_Name, Branch_Address, Branch_Postcode,
Branch_District, Branch_Phone, Branch_Email) values
('Overclockers Puchong', '13, jalan 23, taman kinrara',
 '58000', 'Kuala Lumpur', '03-36512389',
 'overclockerspuchong@gmail.com');
 
 insert into tbl_Branch (Branch_Name, Branch_Address, Branch_Postcode,
Branch_District, Branch_Phone, Branch_Email) values
('Overclockers Kuchai Lama', '45, jalan 10a, taman kuchai',
 '58200', 'Kuala Lumpur', '03-66257498',
 'overclockerskuchailama@gmail.com');
 
 insert into tbl_Branch (Branch_Name, Branch_Address, Branch_Postcode,
Branch_District, Branch_Phone, Branch_Email) values
('Overclockers Cheras', '50, jalan 111a, taman cheras',
 '58300', 'Kuala Lumpur', '03-75692212',
 'overclockerscheras@gmail.com');
