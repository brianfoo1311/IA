insert into tbl_Team (Team_Name) values ('Team Puchong');

insert into tbl_Team (Team_Name) values ('Team KuchaiLama');

insert into tbl_Team (Team_Name) values ('Team Cheras');