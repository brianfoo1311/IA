use testdb;
select * from tutorials_tbl;
create table test (
testID INT NOT NULL AUTO_INCREMENT primary key,
Name varchar(30),
TestDate DATE);
insert into test values (1, 'BABU', current_date());
select * from test;

create database IADatabase;

use IADatabase;

create table tbl_Branch (
Branch_ID int not null auto_increment primary key,
Branch_Name VARCHAR(255),
Branch_Address VARCHAR(255),
Branch_Postcode VARCHAR(255),
Branch_District VARCHAR(255),
Branch_Phone VARCHAR(12),
Branch_Email VARCHAR(255)
);

CREATE TABLE tbl_Staff (
Staff_ID INT not null auto_increment primary key,
Branch_ID INT,
Team_ID INT,
Staff_Name VARCHAR(255),
Staff_Address VARCHAR(255),
Staff_Phone VARCHAR(12),
Staff_Position VARCHAR(255)
);

ALTER TABLE tbl_Staff ADD CONSTRAINT FK_StaffBranch 
FOREIGN KEY (Branch_ID) REFERENCES tbl_Branch(Branch_ID);

ALTER TABLE tbl_Staff ADD CONSTRAINT FK_StaffTeam
FOREIGN KEY (Team_ID) REFERENCES tbl_Team(Team_ID);

CREATE TABLE tbl_Team(
Team_ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
Team_Name VARCHAR(30)
);

CREATE TABLE tbl_Sales(
Sales_ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
Branch_ID INT,
Staff_ID INT,
Product_ID INT,
Order_ID INT,
Sales_Date DATE,
Total_Sales FLOAT(10,2)
);

ALTER TABLE tbl_Sales ADD CONSTRAINT FK_SalesBranch 
FOREIGN KEY (Branch_ID) REFERENCES tbl_Branch(Branch_ID);

ALTER TABLE tbl_Sales ADD CONSTRAINT FK_SalesStaff
FOREIGN KEY (Staff_ID) REFERENCES tbl_Staff(Staff_ID);

ALTER TABLE tbl_Sales ADD CONSTRAINT FK_SalesOrder
FOREIGN KEY (Order_ID) REFERENCES tbl_Order(Order_ID);

CREATE TABLE tbl_Customer(
Customer_ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
Customer_Name VARCHAR(255),
PhoneNumber VARCHAR(15),
Email VARCHAR(255)
);

CREATE TABLE tbl_Order(
Order_ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
Product_ID INT,
Customer_ID INT,
Quantity INT
);

ALTER TABLE tbl_Order ADD CONSTRAINT FK_OrderProduct 
FOREIGN KEY (Product_ID) REFERENCES tbl_Product(Product_ID);

ALTER TABLE tbl_Order ADD CONSTRAINT FK_OrderCustomer
FOREIGN KEY (Customer_ID) REFERENCES tbl_Customer(Customer_ID);

CREATE TABLE tbl_Product(
Product_ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
Product_Name VARCHAR(255),
Product_Type VARCHAR(255),
Product_Price FLOAT(10,2)
);