insert into tbl_Customer (Customer_Name,PhoneNumber,Email) values ('Brian Kong','012-3656663','briankong@gmail.com');

insert into tbl_Customer (Customer_Name,PhoneNumber,Email) values ('Alwin Ha','012-8889921','alwinha@gmail.com');

insert into tbl_Customer (Customer_Name,PhoneNumber,Email) values ('Jeff Bezz','017-44477259','jeffbezz@gmail.com');

insert into tbl_Customer (Customer_Name,PhoneNumber,Email) values ('Musk Kingston','014-3344741','muskkingston@gmail.com');

insert into tbl_Customer (Customer_Name,PhoneNumber,Email) values ('Andrew Prime','011-22547889','andrewprime@gmail.com');

insert into tbl_Customer (Customer_Name,PhoneNumber,Email) values ('Eason Tan','019-6548875','easontan@gmail.com');

insert into tbl_Customer (Customer_Name,PhoneNumber,Email) values ('Gem Yong','019-9956614','gemyong@gmail.com');

insert into tbl_Customer (Customer_Name,PhoneNumber,Email) values ('Clement Tan','012-3996965','clementtan@gmail.com');

insert into tbl_Customer (Customer_Name,PhoneNumber,Email) values ('Irene Chen','018-8847113','irenechen@gmail.com');

insert into tbl_Customer (Customer_Name,PhoneNumber,Email) values ('Uhu Longstar','014-7171556','uhulongstar@gmail.com');

insert into tbl_Customer (Customer_Name,PhoneNumber,Email) values ('Angela Chong','012-5559696','angelachong@gmail.com');

insert into tbl_Customer (Customer_Name,PhoneNumber,Email) values ('Malar Than','019-9914725','malarthan@gmail.com');

insert into tbl_Customer (Customer_Name,PhoneNumber,Email) values ('Yujin Chan','012-2284714','yujinchan@gmail.com');

insert into tbl_Customer (Customer_Name,PhoneNumber,Email) values ('Sana Yong','016-3362258','sanayong@gmail.com');

insert into tbl_Customer (Customer_Name,PhoneNumber,Email) values ('Mina Wayne','016-6699255','minayong@gmail.com');